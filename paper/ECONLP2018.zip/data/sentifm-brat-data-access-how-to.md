# Sentifm brat data access how to:

1. Open Chrome and go to http://lt3serv.ugent.be/sentifm/
2. Access:
    - username: sentifm
    - password: s3nt1fm
    
3. in order to search and perform other action Login in right-most corner:
    - username: els
    - password: els
    
For implicit sentiment anotation:
- For LRE 'The good the bad and the implicit' paper: click /LRE_toannotate/
- 
For economic events:
- For EcoNLP paper all events: http://lt3serv.ugent.be/sentifm/#/events/all/
- Dumped copy on lt3babel.ugent.be:/home/els
 